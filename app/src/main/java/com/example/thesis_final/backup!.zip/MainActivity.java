package com.example.thesis_final;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static MockServer myServer = new MockServer();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText username   = (EditText)findViewById(R.id.editTextTextUserName);
        EditText password   = (EditText)findViewById(R.id.editTextTextPassword);

        ((Button) findViewById(R.id.buttonLogin)).setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        //asynchronous calls
                        myServer.SignInWithBio(username.getText().toString(), v);
                    }
                }
        );


        ((Button) findViewById(R.id.buttonRegister)).setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        Log.e("tag", "hiu");
                        myServer.addUserIfNotExists(username.getText().toString(), password.getText().toString(), v);
                    }
                }
        );


    }




}