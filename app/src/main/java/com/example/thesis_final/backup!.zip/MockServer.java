package com.example.thesis_final;

import static com.example.thesis_final.KeyPairCreation.convertStringToPubKey;
import static com.example.thesis_final.KeyPairCreation.generateKeyPair;
import static com.example.thesis_final.KeyPairCreation.getPubKey;
import static com.example.thesis_final.KeyPairCreation.signMessage;
import static com.example.thesis_final.KeyPairCreation.signedDataLatest;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;

import org.bouncycastle.util.encoders.Base64;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MockServer {
    private static final String TAG = "MockServer";
    private List<User> usersRegistered;

    public MockServer(){
        usersRegistered = new ArrayList<User>();
    }

    public void addUserIfNotExists(String username, String password, View view){
        if(isUserRegistered(username)) {
            new AlertDialog.Builder(view.getContext())
                    .setTitle("User already exists!")
                    .setCancelable(true)
                    .setPositiveButton("Ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            })
                    .show();
            return;
        }

         new AlertDialog.Builder(view.getContext())
                .setTitle("Do you want to associate a biometric?")
                .setCancelable(true)
                .setNegativeButton("No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                usersRegistered.add(new User(username,password));
                            }
                        })
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                generateKeyPair(password);
                                String pubKey = getPubKey();
                                if (pubKey==null){
                                    Toast.makeText(view.getContext(), "Couldn't get public key", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                usersRegistered.add(new User(username,password, pubKey));
                            }
                        })
                .show();

    }


    public boolean isUserRegistered(String username){
        return usersRegistered.contains(new User(username,""));
    }

    public void SignInWithBio(String username, View view){
        if(!isUserRegistered(username)) {
            new AlertDialog.Builder(view.getContext())
                    .setTitle("User does not exists!")
                    .setCancelable(true)
                    .setPositiveButton("Ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            })
                    .show();
            return;
        }

        String message = "something";
        final byte[][] signed = new byte[1][];

        BiometricPrompt.AuthenticationCallback authCallback = new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode,
                                              @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Log.e(TAG,"Authentication error");

            }

            @Override
            public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Log.e(TAG,"Authentication succeeded");
                try {
                    BiometricPrompt.CryptoObject cryptoObject = result.getCryptoObject();
                    Signature cryptoSignature = cryptoObject.getSignature();
                    cryptoSignature.update(message.getBytes(StandardCharsets.UTF_8));
                    signed[0] = cryptoSignature.sign();

                    String signedString = Base64.toBase64String(signed[0]);
                    signedString = signedString.replaceAll("\r", "").replaceAll("\n", "");
                    Log.e(TAG,signedString);
                    signedDataLatest =  signedString;

                    //send signed data to server for verification
                    boolean isvalid = verificationFromServer(username, signed[0]);

                    if(isvalid) {
                        Toast.makeText(view.getContext(), "User logged in", Toast.LENGTH_SHORT).show();
                        ((Activity)view.getContext()).startActivity(new Intent((Activity)view.getContext(), LoggedHomepage.class));
                    }
                    else
                        Toast.makeText(view.getContext(), "Wrong creds", Toast.LENGTH_SHORT).show();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Log.e(TAG,"Authentication failed");

            }
        };

        signMessage("something", view, authCallback);
    }


    private boolean verificationFromServer(String username, byte[] digest) {
        try {
            User mockuser = new User(username, "");
            if(usersRegistered.indexOf(mockuser)==-1) {  //probably not needed!
                Log.e(TAG,"User not exists?");

                return false;
            }

            User current = usersRegistered.get(usersRegistered.indexOf(mockuser));
            Signature sig = Signature.getInstance("SHA256withECDSA");
            sig.initVerify(convertStringToPubKey(current.getPubKey()));
            sig.update("something".getBytes(StandardCharsets.UTF_8));
            boolean verifies = sig.verify(digest);
            Log.e(TAG,"Verification: "+verifies);
            return verifies;

        } catch (NoSuchAlgorithmException | SignatureException | InvalidKeyException e) {
            e.printStackTrace();
        }
        Log.e(TAG, "Failed to verify!");
        return false;
    }

    public boolean validSignInWithPwd(String username, String password, View view){
        if(!isUserRegistered(username)) {
            new AlertDialog.Builder(view.getContext())
                    .setTitle("User does not exists!")
                    .setCancelable(true)
                    .setPositiveButton("Ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            })
                    .show();
            return false;
        }

        User current = usersRegistered.get(usersRegistered.indexOf(new User(username,"")));
        return current.isValidLogin(username,password);
    }

}

class User{
    private String username;
    private String password;
    private String pubKey;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(String username, String password, String pubKey) {
        this(username,password);
        this.pubKey = pubKey;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(username, user.username);
    }

    public boolean isValidLogin(String uname, String pwd){
        return password.equals(pwd) && username.equals(uname);
    }
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getPubKey() {
        return pubKey;
    }
}
