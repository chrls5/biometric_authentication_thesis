package com.example.thesis_final;

import static com.example.thesis_final.KeyPairCreation.getPubKey;
import static com.example.thesis_final.KeyPairCreation.privKeyLatest;
import static com.example.thesis_final.KeyPairCreation.pubKeyLatest;
import static com.example.thesis_final.KeyPairCreation.signedDataLatest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoggedHomepage extends AppCompatActivity implements View.OnLongClickListener {

    TextView pubKeyText, privKeyText, signedDataText;
    ClipboardManager myClipboard;
    final ClipData[] myClip = new ClipData[1];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_homepage);

        TextView linkTextView = findViewById(R.id.loggedin_message);
        linkTextView.setMovementMethod(LinkMovementMethod.getInstance());

        pubKeyText = (TextView) findViewById(R.id.pubKeyView);
        privKeyText = (TextView) findViewById(R.id.privKeyView);
        signedDataText = (TextView) findViewById(R.id.signedDataSent);

        pubKeyText.setText(pubKeyLatest);
        privKeyText.setText(privKeyLatest);
        signedDataText.setText(signedDataLatest);

        //inside oncreate
        myClipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        pubKeyText.setOnLongClickListener(this);
        privKeyText.setOnLongClickListener(this);
        signedDataText.setOnLongClickListener(this);

    }

    @Override
    public boolean onLongClick(View v) {
        String text;

        switch (v.getId()) {
            case R.id.pubKeyView:
                text = pubKeyText.getText().toString();
                break;
            case R.id.privKeyView:
                text = privKeyText.getText().toString();
                break;
            case R.id.signedDataSent:
                text = signedDataText.getText().toString();
                break;
            default:
                text = null;
        }

        if (text == null) {
            return false;
        } else {
            myClip[0] = ClipData.newPlainText("text", text);
            myClipboard.setPrimaryClip(myClip[0]);

            Toast.makeText(getApplicationContext(), "Text Copied",
                    Toast.LENGTH_SHORT).show();
        }

        return true;
    }
}