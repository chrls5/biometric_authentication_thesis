package com.example.thesis_final;

import android.util.Log;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.crypto.prng.FixedSecureRandom;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.util.encoders.Base64;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

public class KeyPairCreation {

    static String pubKeyLatest;
    static String privKeyLatest;
    static String signedDataLatest;



    private static final String TAG = "KEYPAIR";
    private static final String alias = "bio_auth_login";

    private static KeyPair generateKeyPairFromPwd(String password) throws NoSuchAlgorithmException, NoSuchProviderException {

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] seed = digest.digest(
                password.getBytes(StandardCharsets.UTF_8));

        FixedSecureRandom random = new FixedSecureRandom( seed);

        KeyPairGenerator keyGen = KeyPairGenerator.getInstance( "EC", "BC");
        keyGen.initialize( 256, random );
        return keyGen.generateKeyPair();
    }

    private static X509Certificate generateCertificate(KeyPair keyPair )
            throws OperatorCreationException, CertificateException, InvalidKeyException, NoSuchAlgorithmException,
            NoSuchProviderException, SignatureException
    {
        String issuerString = "C=DE, O=datenkollektiv, OU=Planets Debug Certificate";
        // subjects name - the same as we are self signed.
        String subjectString = "C=DE, O=datenkollekitv, OU=Planets Debug Certificate";
        X500Name issuer = new X500Name( issuerString );
        BigInteger serial = BigInteger.ONE;
        Date notBefore = new Date();
        Date notAfter = new Date( System.currentTimeMillis() + (  2 * 365 * 24 * 60 * 60 * 1000l ) );
        X500Name subject = new X500Name( subjectString );
        PublicKey publicKey = keyPair.getPublic();
        JcaX509v3CertificateBuilder v3Bldr = new JcaX509v3CertificateBuilder( issuer,
                serial,
                notBefore,
                notAfter,
                subject,
                publicKey );
        X509CertificateHolder certHldr = v3Bldr
                .build( new JcaContentSignerBuilder( "SHA1WITHECDSA" ).setProvider( "BC" ).build( keyPair.getPrivate() ) );
        X509Certificate cert = new JcaX509CertificateConverter().setProvider( "BC" ).getCertificate( certHldr );
        cert.checkValidity( new Date() );
        cert.verify( keyPair.getPublic() );
        return cert;
    }
    public static String getPubKey() {
        try {
            KeyStore keystore = loadKeystore(null);
            Key key = keystore.getKey(alias, "password".toCharArray());
            if (key instanceof PrivateKey) {
                // Get certificate of public key
                Certificate cert = keystore.getCertificate(alias);

                // Get public key
                PublicKey publicKey = cert.getPublicKey();

                return Base64.toBase64String(publicKey.getEncoded()) ;
            }
        } catch (IOException | CertificateException | NoSuchAlgorithmException | UnrecoverableKeyException | KeyStoreException ioException) {
            ioException.printStackTrace();
        }

        return null;
    }
    public static void generateKeyPair(String password) {
        Security.removeProvider("BC");
        Security.addProvider(new BouncyCastleProvider());

        KeyStore ks;
        try {
            ks = loadKeystore( null );
            KeyPair keyPair = generateKeyPairFromPwd(password);
            X509Certificate certificate = generateCertificate( keyPair );
            ks.setKeyEntry( alias,
                    keyPair.getPrivate(),
                    null,
                    new X509Certificate[]{
                            certificate
                    } );

            Log.e( TAG, Base64.toBase64String(keyPair.getPublic().getEncoded()) );
            Log.e( TAG,Base64.toBase64String(keyPair.getPrivate().getEncoded()) );
            pubKeyLatest =  Base64.toBase64String(keyPair.getPublic().getEncoded());
            privKeyLatest = Base64.toBase64String(keyPair.getPrivate().getEncoded());

//           return keyPair;
        } catch(KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException | NoSuchProviderException | InvalidKeyException | SignatureException | OperatorCreationException e )
        {
            e.printStackTrace();
        }
    }

    private static KeyStore loadKeystore( byte[] keystoreBytes )
            throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException
    {
        KeyStore ks;
        ks = KeyStore.getInstance("AndroidKeystore");
        if( keystoreBytes != null ) {
            ks.load( new ByteArrayInputStream( keystoreBytes ), "android".toCharArray() );
        } else {
            ks.load( null );
        }
        return ks;
    }
    private static PrivateKey getPrivateKey() throws KeyStoreException, UnrecoverableEntryException, NoSuchAlgorithmException, IOException, CertificateException {
        KeyStore keyStore = loadKeystore(null);
        if(keyStore.containsAlias(alias)) {
            KeyStore.Entry entry = keyStore.getEntry(alias, null);
            PrivateKey privateKey = ((KeyStore.PrivateKeyEntry) entry).getPrivateKey();
            return privateKey;
        }
        return null;
    }


    public static void signMessage(String msg, View v, BiometricPrompt.AuthenticationCallback authCallBack){
        try {
            Signature signature = Signature.getInstance("SHA256withECDSA");
            signature.initSign(getPrivateKey());
            BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                    .setDeviceCredentialAllowed(false)
                    .setNegativeButtonText("Cancel?")
                    .setTitle("Signing")
                    .build();
            BiometricPrompt bp = new BiometricPrompt((FragmentActivity) v.getContext(),  ContextCompat.getMainExecutor(v.getContext()), authCallBack);
            bp.authenticate(promptInfo, new BiometricPrompt.CryptoObject(signature));

        } catch (NoSuchAlgorithmException | KeyStoreException | IOException | CertificateException | UnrecoverableEntryException | InvalidKeyException e) {
            e.printStackTrace();
        }
    }

//    private static BiometricPrompt.AuthenticationCallback getAuthCallbackForSigning(){
//        BiometricPrompt.AuthenticationCallback authCallback = new BiometricPrompt.AuthenticationCallback() {
//            @Override
//            public void onAuthenticationError(int errorCode,
//                                              @NonNull CharSequence errString) {
//                super.onAuthenticationError(errorCode, errString);
//                Log.e(TAG,"Authentication error");
//
//            }
//
//            @Override
//            public void onAuthenticationSucceeded(
//                    @NonNull BiometricPrompt.AuthenticationResult result) {
//                super.onAuthenticationSucceeded(result);
//                Log.e(TAG,"Authentication succeeded");
//                try {
//                    BiometricPrompt.CryptoObject cryptoObject = result.getCryptoObject();
//                    Signature cryptoSignature = cryptoObject.getSignature();
//                    cryptoSignature.update(message.getBytes(StandardCharsets.UTF_8));
//                    byte[] signed = cryptoSignature.sign();
//                    digest = signed;
//                    String signedString = Base64.toBase64String(signed);
//                    signedString = signedString.replaceAll("\r", "").replaceAll("\n", "");
//                    Log.e(TAG,signedString);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//
//            @Override
//            public void onAuthenticationFailed() {
//                super.onAuthenticationFailed();
//                Log.e(TAG,"Authentication failed");
//
//            }
//        };
//
//        return authCallback;
//    }

    public static PublicKey convertStringToPubKey(String key){
        try{
            byte[] byteKey = Base64.decode(key.getBytes());
            X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
            KeyFactory kf = KeyFactory.getInstance("EC");
            return kf.generatePublic(X509publicKey);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }


}
