package com.example.thesis_final;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

public class Login {

    private void loginWithBiometrics(){
        //Load keystore
        //prompt biometrics and Sign something!
        //Send it to Server and wait for validation (verify)
    }

}
